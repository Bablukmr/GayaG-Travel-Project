function Mainpage() {
  return (
    <div className="mainPage">
      <img src={require("./")} alt="Gautam Budha" />
    </div>
  );
}
export default Mainpage;
